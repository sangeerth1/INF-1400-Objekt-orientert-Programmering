import pygame


black =(0,0,0) # fargen til svart 
red = (255,0,0) # fargen til rød
blue = (0,0,125) # fargen til blå 
green = (0,255,0) # fargen til grønn
white = (255,255,255) # fargen til hvit

SCREEN_X = 1500  # Skjermens størrelse i x-retning
SCREEN_Y = 800	# Skjermens størrelse i y-retning 

#Ballens Variabler
BALL_X = SCREEN_X/2+20
BALL_Y = SCREEN_Y/2
BALL_R = 15 	# Ballens Radius

# Brikkens Variabler
BRICK_W = 100  # Brikkens bredde
BRICK_H = 50	# Brikkens høyde 

# Paddlen Variabler
PADDLE_WIDTH = 500  # Paddelen sitt bredde 
PADDLE_HEIGHT = 50	# Paddelen sitt høyde

#Brikkens Variabler  
KOLONNER = 14 # Antall kolonner 
RADER = 5 # Antall rader

SCREEN_W = SCREEN_X/2
SCREEN_H = SCREEN_Y/2


screen = pygame.display.set_mode((SCREEN_X,SCREEN_Y)) #Setter opp skjermen


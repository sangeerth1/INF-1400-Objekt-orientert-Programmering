import pygame
import sys
import time 
import random
from precode import Vector2
from precode import intersect_rectangle_circle
import Config as c 

pygame.init()

class Ball():
	def __init__(self,x,y,r):
		self.x = x  # x- retning
		self.y = y  # y - retning 
		self.r = r  # r - retning

		self.speed = Vector2(5.5,5.5) # Hastigheten til ballen
		



	def draw_the_ball(self,screen):

		pygame.draw.circle(screen,c.green,(int(self.x),int(self.y)),self.r) # Tegner sirkelen


	def move_the_ball(self,screen,text):
		
		self.x += self.speed[0]
		self.y += self.speed[1]



		if self.x <= self.r:  
			self.speed[0] = abs(self.speed[0])	
			# treffer høyre vegg
		if self.x>= c.SCREEN_X-self.r: 
			self.speed[0]= -abs(self.speed[0]) 

		if self.y <= self.r: # treffer toppen
			self.speed[1]= abs(self.speed[1])

		if self.y >= c.SCREEN_Y-self.r: # treffer bunnen
			self.speed[1] = -abs(self.speed[1])


			c.screen.blit(text,(c.SCREEN_W-(text.get_width() /2), c.SCREEN_H - (text.get_height()/2)))
			pygame.display.update() # Oppdaterer spillet

			time.sleep(5)	

			
			
			quit() # slutter spillet

class Pad():
	def __init__(self,x,y,w,h):

		self.color = c.blue # fargen blå
		self.rect = pygame.Rect(x,y,w,h)
		self.speed = 10 # hastigheten ti
		self.pos = Vector2(x,y)
	def draw_the_pad(self,screen):
		
		self.pad = pygame.draw.rect(screen,self.color, self.rect) # Tegner paddelen


	def move_the_pad(self, direction):
		if direction == 0 and self.rect.right < c.SCREEN_X:
			self.rect.x += self.speed 
		if direction == 1 and self.rect.x> 0:
			self.rect.x -= self.speed	

class Brick():
	def __init__(self,x,y,w,h):

		self.rect = pygame.Rect(x,y,w,h)  


	def draw_the_brick(self,screen):

		pygame.draw.rect(screen,c.white,self.rect) # Tegner Brikken



class Bricklist():
	
	def __init__(self):

		self.brick_list = [] # liste over alle brikkene
		for i in range(c.KOLONNER): # det er fjorten brikker med hvitt farge
			for j in range(c.RADER): # det er fem brikker med hvitt farge langs lodrett
				self.brick_list.append((Brick(10*i + i * c.BRICK_W,10*j+c.BRICK_H*j,c.BRICK_W,c.BRICK_H)))



	def draw(self,screen):


		for brick in self.brick_list: # Iterer gjennom brick i brikkene
			brick.draw_the_brick(screen) # Tegner brikken på skjermen
	

	def handle_collide(self, ball):

		for brick in self.brick_list: # Iterer gjennom brick i brikkene
			treff,impulse = intersect_rectangle_circle(Vector2(brick.rect.x,brick.rect.y),brick.rect.w,brick.rect.h,Vector2(ball.x,ball.y),ball.r,(ball.speed))

			if treff: 
				ballspeed = Vector2(ball.speed)
				ball.speed = impulse * ballspeed.length()
				
				self.brick_list.remove(brick) # Fjerner brikkene
				

				if len(self.brick_list)== 0: # Hvis alle brikkene er borte 
					c.screen.blit(text2,(c.SCREEN_W-(text2.get_width() /2), c.SCREEN_H - (text2.get_height()/2)))
					pygame.display.update() # Oppdaterer spillet
					time.sleep(5)

					quit() # avslutter 




class Game():
	
	def __init__(self):
		self.b = Ball(c.BALL_X,c.BALL_Y,c.BALL_R) # ballens sitt posisjon med bredde,høyde og radius
		self.paddle = Pad(c.SCREEN_X/2,c.SCREEN_Y-150,c.PADDLE_WIDTH,c.PADDLE_HEIGHT) # Paddelen sitt posisjon med bredde og høyde 
		self.bricklist = Bricklist()
		self.clock = pygame.time.Clock() # Klokkens tid 
	
		self.font = pygame.font.Font(None,72)
		self.text = self.font.render("Gameover", True, (c.white))  # skriver game over på skjermen
		self.text2 = self.font.render("WIN",True,(c.green))  # Skriver win på skjermen

		self.background = pygame.image.load("zlatan.jpg").convert() # loader bildet
		self.background = pygame.transform.scale(self.background,(c.SCREEN_X,c.SCREEN_Y)) # scalerer bildet

	def gameloop(self):
		
		self.running = True
		while self.running:
			self.draw()
			self.event()
			self.collide()
			self.clock.tick(60) #Klokken tikker på 30

			pygame.display.update()  # Oppdaterer displayen 




	def draw(self):
		c.screen.blit(self.background, (0,0))
		self.b.draw_the_ball(c.screen) # Tegner ballen på skjermen
		self.bricklist.draw(c.screen) # Tegner brikkene 
		self.b.move_the_ball(c.screen,self.text) # Beveger ballen
		self.bricklist.handle_collide(self.b) # kolliderer brikkene

		self.paddle.draw_the_pad(c.screen)  # Tegner paddelen

	def event(self):
		events = pygame.event.get()
		for event in events:
			if event.type == pygame.QUIT:
				running = False
		keys = pygame.key.get_pressed()
		if keys[pygame.K_RIGHT]:        # Hvis det er til høyre trykk høyre
			self.paddle.move_the_pad(0)

		if keys[pygame.K_LEFT]:  # Hvis det er til venstre trykk venstre
			self.paddle.move_the_pad(1)

	def collide(self):

		treff, impulse = intersect_rectangle_circle(Vector2(self.paddle.rect.x,self.paddle.rect.y,),self.paddle.rect.w,self.paddle.rect.h,Vector2(self.b.x,self.b.y),self.b.r,(self.b.speed))
		

		if treff:
			
			vector_a = (self.b.x - (self.paddle.rect.x+self.paddle.rect.w/2))
			vector_b = (self.b.y - (self.paddle.rect.y+self.paddle.rect.h))
			vector_c = Vector2(vector_a, vector_b).normalize() # Normaliserer begge vektorene 
			self.b.speed = vector_c*self.b.speed.length()
			print(self.b.speed.length())






if __name__ == "__main__":
	game = Game()
	game.gameloop()



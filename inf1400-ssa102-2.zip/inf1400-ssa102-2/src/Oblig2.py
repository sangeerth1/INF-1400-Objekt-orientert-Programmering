import pygame
import time
import sys
import random 
import math
import Config2 as c
from precode2 import Vector2 

pygame.init()


class object():
	def __init__(self):
		self.left= 10
		self.top= 10
		self.height = 10
		self.width = 10
		
		self.pos = Vector2(random.randint(0,c.SCREEN_X),random.randint(0,c.SCREEN_Y)) #  Posisjon med skjermens x- retning og y -retning
		print(self.pos.x,self.pos.y)
		
		self.speed = Vector2(random.randint(0,10),random.randint(0,10)) # Farten 
		self.maxspeed = 2  # maxfarten er to

		
	def move(self):
		self.pos += self.speed 

		if self.pos.x > c.SCREEN_X:
				self.pos.x = 0

		if self.pos.x < 0: 
				self.pos.x = c.SCREEN_X

		if self.pos.y > c.SCREEN_Y:
				self.pos.y = 0

		if self.pos.y < 0:
				self.pos.y = c.SCREEN_Y




class Boid(object):
	def __init__(self): 
		super().__init__()
		self.r = c.BOIDS_R # Boids sitt radius
		


	def draw(self,screen):
		pygame.draw.circle(c.screen,c.green,(int(self.pos.x),int(self.pos.y)),self.r) # Tegner sirkel med Grønn farge



	def rule1(self,andre_boids):
		""" Boids try to fly towards the centre of mass of neighbouring boids"""
		samling = Vector2(0,0)

		if not andre_boids: return samling 

		for boid in andre_boids:
				if self != boid:
					samling = samling + boid.pos 

				samling = samling/ len(andre_boids) #-1 

		return (samling-self.pos).normalize() 


	def rule2(self,andre_boids):
		"""Boids prøver å holde en liten avstand fra andre objects"""

		avoid = Vector2(0,0)


		if not andre_boids: return avoid

		for boid in andre_boids: 

				if self != boid:
						v = (self.pos-boid.pos).length()
						if abs(v) < 100:
							avoid += boid.pos
		if avoid == (0,0):return avoid					
			
		return(avoid).normalize()		 	 

	def rule3(self, andre_boids):
		""" Boids prøver å matche hastigheten nærliggende boids"""

		preve = Vector2(0,0)

		if not andre_boids: return preve

		for boid in andre_boids:

				if self != boid:
					preve = preve+ boid.speed
					preve = preve/len(andre_boids)
		if preve:
			return preve.normalize()
		return preve

	def obstacle_rule(self,andre_obstacles):
		avoid = Vector2(0,0)



		for obstacle in andre_obstacles: 

			v = (self.pos-obstacle.pos).length()
			if abs(v) < 400:
				avoid += obstacle.pos
			
		if avoid == (0,0):return avoid					
			
		return avoid.normalize()	

	def hoick_rule(self,andre_hoicks):
		avoid = Vector2(0,0)

		for hoick in andre_hoicks:
			v = (self.pos-hoick.pos).length()
			if abs(v) < 200:
				avoid += hoick.pos
		if avoid == (0,0):return avoid					
			
		return(avoid).normalize()
	
	def update(self,andre_boids,andre_obstacles,andre_hoicks):

		andre_boids = self.nabo(andre_boids)
		


		v1_weight = 1
		v2_weight = 0.8 # Her skal man vektlegge styrken til boids a avhengig av de treffer hverandre #8
		v3_weight = 1 
		v4_weight = 10

		v1 = self.rule1(andre_boids) *v1_weight # her ganger sammen regel 1  med vektor 1 sitt vekt

		v7 = self.rule2(andre_obstacles) *v2_weight *100 # her ganger sammen regel 2 med vektor 2 sitt vekt
		v8 = self.rule2(andre_hoicks) * v2_weight *100  # her ganger sammen regel 2 med vektor 2 sitt vekt
				
		v2 = self.rule2(andre_boids) *v2_weight
		v3 = self.rule3(andre_boids) *v3_weight 
		


		self.speed = self.speed + v1+v2+v3+v7+v8 # Plusser sammen med alle vektorene pluss farten
		self.limit_velocity()  # limit farten


		self.pos = self.pos + self.speed 

	def nabo(self, andre_boids):
		naboer = [] # liste over naboer

		for boid in andre_boids: # Iterer over alle boids
				if boid is self:continue 
				if (self.pos - boid.pos).length() < self.r*20:
						naboer.append(boid)


		return naboer

	

	def limit_velocity(self):
		""" limiterer farten"""
		
		V = Vector2(0,0)

		if (self.speed).length() > self.maxspeed:
				self.speed = self.speed.normalize()* self.maxspeed 


class Game():
	def __init__(self):
		
		self.clock = pygame.time.Clock() # Klokkens tid
		self.running = True
		self.boids_liste = [] # lister over alle boids
		self.obstacles_liste = [] # lister over alle obstacles
		self.hoicks_liste = []  #  lister over alle hoicks
		
		self.screen = c.screen
		 
		for i in range(c.antallboids): # Looper gjennom antall boids som er ti 
			self.boid = Boid()
			self.boids_liste.append(self.boid) # Legger til boid i lista 
			
		for i in range(c.antallobstacles): #Looper gjennom antall obstacles som er en
			self.obstacle = Obstacle()
			self.obstacles_liste.append(self.obstacle) # Legger til Obstacle i lista 

		for i in range(c.antallhoicks):  # Looper gjennom antall hoicks som er to
			self.hoick = Hoick()
			self.hoicks_liste.append(self.hoick) # Legger til Hoick i lista
			




	def draw(self):

		self.screen.fill(c.black) # fyller skjermen svart
		for boid in self.boids_liste: # Iterer over listene til boid
			boid.draw(self.screen) # Tegner boid
			 
		for obstacle in self.obstacles_liste:  # Iterer over listene til obstacle	
			obstacle.draw(self.screen) # Tegner Obstacle 

		for hoick in self.hoicks_liste:  # Iterer over listene til hoick
			hoick.draw() # Tegner hoicken 
			

		

		pygame.display.update() #Oppdaterer skjermen 
	
	def events(self):

		events = pygame.event.get()
		for event in events:
			if event.type == pygame.QUIT:
				self.running = False

	def move(self):

		for boid in self.boids_liste: # Får boiden til å bevege på seg 
			boid.move() 

		
		for hoick in self.hoicks_liste:  # Får hoicken til å bevege på seg 
			hoick.move()
			
	
	def gameloop(self):

		while self.running:
				self.draw()
				self.events()
				self.move()
				self.update()

				self.clock.tick(60) # Klokken tikker på 60

	def update(self):
		for boid in self.boids_liste: # Iterer gjennom boid sine lister
			boid.update(self.boids_liste,self.obstacles_liste,self.hoicks_liste) # oppdaterer boids sine lister , obstacle sine lister , og hoicks sine lister

	

		for hoick in self.hoicks_liste: # Iterer gjennom hoick sine lister
			hoick.update(self.hoicks_liste,self.obstacles_liste,self.boids_liste) # Oppdaterer hoick sine lister , obstacle sine lister og hoick sine lister	




class Hoick(object):
	def __init__(self):
		super().__init__()
		self.r = c.HOICKS_R  # Hoick sitt radius 
		

	def draw(self):
		
		
		pygame.draw.circle(c.screen,c.blue,(int(self.pos.x),int(self.pos.y)),self.r) # Tegner sirkeler  med blå  farge 

	def limit_velocity(self): 
		""" Limiterer farten"""
		V = Vector2(0,0)

		if (self.speed).length() > self.maxspeed:
				self.speed = self.speed.normalize()* self.maxspeed 

	def rule(self,andre_obstacles):
		avoid = Vector2(0,0)

		for obstacle in andre_obstacles: 

			v = (self.pos-obstacle.pos).length()
			if abs(v) < 400:
				avoid += obstacle.pos
				
		if avoid == (0,0):return avoid
								
			
		return(avoid).normalize()



	def chase_the_thing(self):
		if not game.boids_liste: # Hvis ikke det er i lista
			return (0,0)  # returner null

		def key(fish_friendly): 

			return(fish_friendly.pos-self.pos).length()

		nearby = min(game.boids_liste,key = key)
		nearby_distance =(nearby.pos-self.pos).length()



		chase_distance = (nearby.pos - self.pos)
		chase_distance -= self.speed

		if chase_distance !=(0,0):
			chase_distance = chase_distance.normalize()
		return (chase_distance)	

	def kill_the_boids(self,boids):

		for boid in boids:
			if boid.pos.distance_to(self.pos) < boid.r + self.r:
				boids.remove(boid) # spiser boiden når hoicken treffer boiden

			

	def update(self,hoicklist,obstacles_liste,boids_liste):
		for hoick in hoicklist:
			hoick.move()
			hoick.draw() # oppdaterer hoick sitt tegning
			hoick.kill_the_boids(boids_liste)
			
			hoick.rule(obstacles_liste)
			
			v1 = hoick.chase_the_thing()
			self.speed += v1
			hoick.limit_velocity()	# oppdaterer hoick sin fart


class Obstacle():
	def __init__(self):

		self.speed = Vector2(random.randint(0,10),random.randint(0,10))  # Random hastighet 
		self.pos = Vector2(c.SCREEN_X/2,c.SCREEN_Y/2) # Posisjon til Obstacle
		self.r = c.OBSTACLES_R # Obstacles sitt radius

	def draw(self,screen):
		
		pygame.draw.circle(c.screen,c.white,(int(self.pos.x),int(self.pos.y)),self.r) # Tegner sirkelen som er hvit farge 


	



if __name__ == "__main__":
	game = Game()
	game.gameloop()




























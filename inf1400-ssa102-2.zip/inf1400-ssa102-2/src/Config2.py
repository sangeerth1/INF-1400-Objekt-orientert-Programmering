import pygame




""" antall farger"""
black = (0,0,0)
white = (255,255,255)
blue = (0,0,125) 
green = (0,255,0)
red = (255,0,0) 

""" Boid sine variabler"""

BOIDS = []
BOIDS_X = 200
BOIDS_Y = 200
BOIDS_R = 20 

""" Obstacler sine variabler"""
OBSTACLES_X = 50
OBSTACLES_Y = 50
OBSTACLES_R = 50 
OBSTACLES = [] 

""" Hoicks sine variabler"""
HOICKS_X = 100
HOICKS_Y = 100
HOICKS_R = 50



SCREEN_X = 1500 # Skjermens Størrelse i x- retning
SCREEN_Y = 800  # Skjermens Størrelse i y - retning  

antallboids = 10 # antall boids 
antallobstacles = 1 # antall obstacler 
antallhoicks = 2  # antall hoicks


screen = pygame.display.set_mode((SCREEN_X,SCREEN_Y)) # sette opp skjermen 
import pygame
import random 
import sys
import time
import math 
from precode import Vector2
from math import cos,sin,radians,pi
import Config3 as c 


class Player1(pygame.sprite.Sprite):
	def __init__(self,x, y, Player1_photo):
		pygame.sprite.Sprite.__init__(self)
 		
		self.image = pygame.image.load(Player1_photo).convert_alpha()
		self.image_size = Vector2(70,100)
		self.image = pygame.transform.scale(self.image,(70,100))
		self.rect = self.image.get_rect()
		
		
		self.pos = Vector2(x,y)
		self.rect.center = self.pos
		self.angle = c.START_ANGLE
		self.orginal = self.image
		self.maxspeed = c.PLAYER_MAXSPEED
		self.speed = Vector2(0,0)
		self.hit_points = 10
		self.health = c.HEALTHNUM
		self.score =  c.SCORE_MAGIC
		self.bullets = c.BULLETSNUM
		self.fuel = c.FUELNUM


	def respawn(self):
		self.pos.x = random.randrange(c.SCREEN_X)		
		self.pos.y = random.randrange(c.SCREEN_Y)		
		self.rect.center = self.pos
		self.hit_points = 10



	def draw(self):
		screen.blit(self.image,(self.pos.x, self.pos.y))

	def rotate_ship(self,angle):

		""" får romskipene til å rotere"""

		self.angle += angle
		self.angle %= 360
		self.image = pygame.transform.rotate(self.orginal,self.angle)
		self.rect = self.image.get_rect()
		self.rect.center = self.pos



	def rotate_power(self):

		if self.fuel > 0:
			self.rad = radians(self.angle +90)
			self.speed.x += (cos(self.rad))	
			self.speed.y += (-sin(self.rad))


	def limit_velocity(self):
			"""limiterer farten"""
			
			V = Vector2(0,0)
			if (self.speed).length() > self.maxspeed:
				self.speed = self.speed.normalize()* self.maxspeed 	

	def gravity(self):
		""" gravitasjonen til romskipene"""
			
		self.speed = self.speed + c.G

	def rocket_bullet(self, bullet):

		""" får romskipene til å skyte skudd"""

		
		bullet.add(Bullet(self.rect.centerx, self.rect.centery,self.angle))



	def update(self):

		self.gravity()
		self.limit_velocity()
		print(self.angle)
		self.pos += self.speed 

		if self.pos.x > c.SCREEN_X:
				self.pos.x = 0

		if self.pos.x < 0: 
				self.pos.x = c.SCREEN_X

		if self.pos.y > c.SCREEN_Y:
				self.pos.y = 0

		if self.pos.y < 0:
				self.pos.y = c.SCREEN_Y


		self.rect.center = self.pos	 

		print(self.fuel)






class Game():
	
	def __init__(self):

		pygame.init()

		self.running = True

		self.spaceship = pygame.sprite.Group() 
		self.bullet = pygame.sprite.Group()
		self.metior = pygame.sprite.Group()
		self.spaceship_2 = pygame.sprite.Group()
		self.bullet_2 = pygame.sprite.Group()
		self.fuel_tank = pygame.sprite.Group()

		

		


		self.ship1 = Player1(c.SCREEN_X//2 -300,c.SCREEN_Y//2,"player1.png")

		self.spaceship.add(self.ship1) # legger til ship1 i sprites group

		self.ship2 = Player1(c.SCREEN_X//2 +400,c.SCREEN_Y//2,"player2.png")

		self.spaceship.add(self.ship2) # legger til ship2 i sprites group

		self.met = Metior(c.SCREEN_X//2 -100,c.SCREEN_Y//2,"metior_file.png")
		self.metior.add(self.met)

		self.fuel = Fuel(c.SCREEN_X//2 +500,c.SCREEN_Y//2,"fuel_file.png")
		self.fuel_tank.add(self.fuel) # legger til fuel i sprites group








		self.clock = pygame.time.Clock() # Klokkens tid
		self.score = c.SCORE_MAGIC


	def draw(self):
		""" Tegner alle Objektene"""
		c.screen.fill(c.white) # Tegner skjermen hvit
		self.bullet.draw(c.screen) #Tegner skuddene
		self.bullet_2.draw(c.screen) #Tegner skuddene på romskip 2
		self.spaceship.draw(c.screen) #Tegner romskipet
		self.spaceship_2.draw(c.screen) #Tegner romskip 2
		self.metior.draw(c.screen) # Tegner selve obstaclen
		self.fuel_tank.draw(c.screen) #Tegner Fuel tanken
		
		
		

	
		font = pygame.font.Font(None,70)
		scoretext = font.render("Score:" + str(self.ship1.score),1,(c.black))
		c.screen.blit(scoretext,(c.text_padding_right,c.screenh))

		font = pygame.font.Font(None,70)
		scoretext = font.render("Score-spiller:" + str(self.ship2.score),1,(c.black))
		c.screen.blit(scoretext,(c.text_padding_right_2,c.screenw))

		font = pygame.font.Font(None,50)
		scoretext = font.render("Fuel:" + str(self.ship1.fuel),1,(c.black))
		c.screen.blit(scoretext,(c.text_padding_right_3,c.screenh_2))

		font = pygame.font.Font(None,50)
		scoretext = font.render("Fuel_2:" + str(self.ship2.fuel),1,(c.black))
		c.screen.blit(scoretext,(c.text_padding_right_4,c.screenw_2))





		pygame.display.update() # Opdaterer selve spillet


	def check_collisons(self):
		
		""" sjekke kollisjonen mellom romskip og metior"""
		
		if pygame.sprite.collide_rect(self.ship1,self.met):
			self.ship1.hit_points -=1
			print("hit!")

		if self.ship1.hit_points < 1:
			self.ship1.respawn()
			self.ship1.score -=1


		""" sjekke kollisjonen mellom romskip 2 og metior"""

		if pygame.sprite.collide_rect(self.ship2,self.met):
			self.ship2.hit_points -=1
			print("hit!")

			

		if self.ship2.hit_points < 1:


			self.ship2.respawn()
			self.ship2.score -=1
			

		""" sjekke kollisjonen mellom romskip og skuddene"""			


		if pygame.sprite.spritecollide(self.ship1,self.bullet_2,True):
			self.ship1.hit_points -=1
			
			print("hit!")

			
			self.ship2.score += 1 

		if self.ship1.hit_points < 1:
			self.ship1.respawn()


			
		


		""" sjekke kollisjonen mellom romskip 1 og bensinen"""

		if pygame.sprite.spritecollide(self.ship1, self.fuel_tank, False):
			self.fuel_tank.remove(self.fuel_tank)
			


			
			self.ship1.fuel +=1000

			print(self.fuel)
			
		

			

		""" sjekke kollisjonen mellom romskip2 og bensinen"""

		if pygame.sprite.spritecollide(self.ship2,self.fuel_tank,False):
			self.fuel_tank.remove(self.fuel_tank)

			self.ship2.fuel +=1000
			print(self.fuel)

			

	
			



		""" sjekke kollisjonen mellom romskip2 og skuddene"""

		if pygame.sprite.spritecollide(self.ship2,self.bullet,True):
			self.ship2.hit_points -=1	
			print("hit!")	

			self.ship1.score +=1	

		if self.ship2.hit_points <1:
			self.ship2.respawn()



		""" sjekke kollisjonen mellom begge romskipene"""
	
		if pygame.sprite.collide_rect(self.ship1,self.ship2):

			
			print("hit!")	

			self.ship2.respawn()
			self.ship2.score -=1	
				

		 
			self.ship1.respawn()
			self.ship1.score -=1




	def handle_events(self):

		""" her er knappene til å styre spillet"""
		
		events = pygame.event.get()
		for event in events:
			 if event.type == pygame.QUIT:
			 	self.running = False

		keys = pygame.key.get_pressed()

		if keys[pygame.K_RIGHT]:
			self.ship1.rotate_ship(-2)
		if keys[pygame.K_LEFT]:
			self.ship1.rotate_ship(2)

		if keys[pygame.K_a]:
			self.ship2.rotate_ship(-2)


		if keys[pygame.K_d]:
			self.ship2.rotate_ship(2)


		if keys[pygame.K_UP]:
			self.ship1.rotate_power()
			if self.ship1.fuel > 0:
				self.ship1.fuel -=1




		if keys [pygame.K_w]:
			self.ship2.rotate_power()
			if self.ship2.fuel > 0:
				self.ship2.fuel -=1

		if keys[pygame.K_DOWN]:
			self.ship1.rocket_bullet(self.bullet)


		if keys[pygame.K_s]:
			self.ship2.rocket_bullet(self.bullet_2)	
					

	

	def gameloop(self):
		while self.running:
			self.draw()
			self.handle_events()
			self.update()
			self.check_collisons()

			self.clock.tick(c.FPS)


	def update(self):

		"""oppdaterer selve spillet"""
		self.bullet.update()	
		self.spaceship_2.update()
		self.bullet_2.update()
		self.spaceship.update()
		self.metior.update()
		self.fuel_tank.update()
			







		

class Bullet(pygame.sprite.Sprite):
	def __init__(self,x,y,angle):
		super().__init__()
		self.image = pygame.Surface((10,20))
		self.image.fill(c.red)
		self.rect = self.image.get_rect()
		self.rect.x = x
		self.rect.y = y
		self.pos = Vector2(self.rect.centerx,self.rect.centery)

		self.radians = radians(angle + 90) 

		
		# angle to vectors
		self.speed = Vector2(cos(self.radians),(-sin(self.radians))).normalize() * 5

	def move(self):
		self.pos += self.speed
		self.rect.center = self.pos

	def update(self):

		self.move()


		


class Metior(pygame.sprite.Sprite):
	def __init__(self,x,y,metior_file):
		super().__init__()
		
		self.image = pygame.image.load(metior_file).convert_alpha() # loader bildet
		self.rect = self.image.get_rect()
		self.rect.x = x
		self.rect.y = y
		self.pos = Vector2(200,200) # posisjon til bildet

	


class Fuel(pygame.sprite.Sprite):
	def __init__(self,x,y,fuel_file):
		super().__init__()

		self.image = pygame.image.load(fuel_file).convert_alpha() #loader bildet
		self.rect = self.image.get_rect()
		self.rect.x = x
		self.rect.y = y
		self.pos = Vector2(200,200) # posisjon til bildet
		self.fuel = 100


	def update(self):

		self.rect.center = self.pos
		keys = pygame.key.get_pressed()

		

		





	
if __name__  =="__main__":
		game = Game()
		game.gameloop()



		




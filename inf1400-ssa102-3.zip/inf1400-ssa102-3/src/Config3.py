import pygame
from precode import Vector2




black =(0,0,0) # fargen til svart 
red = (255,0,0) # fargen til rød
blue = (0,0,125) # fargen til blå 
green = (0,255,0) # fargen til grønn
white = (255,255,255) # fargen til hvit
purple = ( 128,   0, 255) # fargen til lilla
pink =( 255,   0, 255) # fargen til rosa

grey  = ( 160, 160, 160) # fargen til grå



SCREEN_X = 1500 # skjermens størrelse i x-retning
SCREEN_Y = 800 # skjermens størrelse i y - retning

Player1_photo = "player1.png"
Bullets_photo = "bullets_file.png"	
Metior_file = "metior_file.png"
Fuel_file = "fuel_file.png"
Player2_photo = "player2.png"


Player1_photo_size_x = 50 
text_padding_right = 0  

screenw = 1500 
screenh = 0


text_padding_right_2 = 1100

screenh_2 = 320

screenh_3 = 500
screenw = 0
PLAYER_MAXSPEED = 4
FUELNUM = 1000
START_ANGLE = 0
HEALTHNUM = 0
BULLETSNUM = 0
SCORE_MAGIC = 0



text_padding_right_3 = 120

text_padding_right_4 = 1200
screenw_2 = 300

G=Vector2(0, 0.1)

FPS = 60 # clockkens tid

gravity =Vector2(0, 0.1) # gravitasjons x og y


screen = pygame.display.set_mode((SCREEN_X,SCREEN_Y)) #Setter opp skjermen
